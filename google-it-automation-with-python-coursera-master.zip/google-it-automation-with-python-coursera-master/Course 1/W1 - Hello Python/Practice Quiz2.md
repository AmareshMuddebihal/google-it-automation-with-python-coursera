# Practice Quiz: Hello World

## 1.What are functions in Python?

    Functions are pieces of code that perform a unit of work.


## 2.What are keywords in Python?

    Keywords are reserved words that are used to construct instructions.


## 3.What does the print function do in Python?

    The print function outputs messages to the screen


## 4.Output a message that says "Programming in Python is fun!" to the screen.

    print("Programming in Python is fun!")

## 5.Replace the ___ placeholder and calculate the Golden ratio: \frac{1+\sqrt{5}}{2} Tip: to calculate the square root of a number xx, you can use x**(1/2).

    ratio = (1+5**(1/2))/2
    print(ratio)
