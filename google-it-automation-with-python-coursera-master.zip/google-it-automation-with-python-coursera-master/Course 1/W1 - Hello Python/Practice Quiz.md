# Practice Quiz: Introduction to Programming

## 1.What’s a computer program?

    A list of instructions that the computer has to follow to reach a goal

## 2.What’s the syntax of a language?

    The rules of how to express things in that language


## 3.What’s the difference between a program and a script?

    There’s not much difference, but scripts are usually simpler and shorter.

## 4.Which of these scenarios are good candidates for automation? Select all that apply.

    Generating a sales report, split by region and product type
    Copying a file to all computers in a company
    Sending personalized emails to subscribers of your website

## 5.What are semantics when applied to programming code and pseudocode?

    The effect the programming instructions have
