

cd /data/feedback
ls
cat 007.txt


cd ~

nano run.py

chmod +x ~/run.py
./run.py

