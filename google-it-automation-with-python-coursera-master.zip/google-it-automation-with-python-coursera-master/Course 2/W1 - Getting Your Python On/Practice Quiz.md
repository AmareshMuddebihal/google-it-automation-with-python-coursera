# Practice Quiz: Getting Ready for Python

### 1.Which of the following is the most modern, up-to-date version of Python?

    Python 3

### 2.Which of the following operating systems is compatible with Python 3?

    All of the above

### 3.Which of the following operating systems does not run on a Linux kernel?

    Mac OS

### 4.If we want to check to see  what version of Python is installed, what would we type into the command line? Select all that apply.

    python -V
    python --version

### 5.What is pip an example of?

    A Python package manager