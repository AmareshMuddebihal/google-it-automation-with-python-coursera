# Practice Quiz: Python Subprocesses

### 1.What type of object does a run function return?

  CompletedProcess

### 2.How can you change the current working directory where a command will be executed?

  Use the cwd parameter.

### 3.When a child process is run using the subprocess module, which of the following are true? (check all that apply)

  The child process is run in a secondary environment.
  The parent process is blocked while the child process finishes.
  Control is returned to the parent process when the child process ends.

### 4.When using the run command of the subprocess module, what parameter, when set to True, allows us to store the output of a system command?

  capture_output

### 5.What does the copy method of os.environ do?

  Creates a new dictionary of environment variables
