# Practice Quiz: Data Streams


### 1.Which command will print out the exit value of a script that just ran successfully?

  echo $?

### 2.Which command will create a new environment variable?

  export

### 3.Which I/O stream are we using when we use the input function to accept user input in a Python script?

  STDIN

### 4.What is the meaning of an exit code of 0?

  The program ended successfully.

### 5.Which statements are true about  input and raw_input in Python 2? (select all that apply)

  input performs basic math operations.
  raw_input gets a string from the user.
