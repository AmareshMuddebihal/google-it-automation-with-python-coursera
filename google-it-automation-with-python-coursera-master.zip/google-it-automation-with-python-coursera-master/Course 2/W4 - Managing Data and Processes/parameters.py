import sys

print(sys.argv)

# echo $?