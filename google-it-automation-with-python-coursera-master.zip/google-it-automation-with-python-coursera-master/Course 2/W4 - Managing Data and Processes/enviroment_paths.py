import os

print("HOME: ",os.environ.get("HOME",""))
print("SHELL: ",os.environ.get("SHELL",""))
print("PATH: ",os.environ.get("PATH",""))
