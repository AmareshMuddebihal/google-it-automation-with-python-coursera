# Practice Quiz: Bash Scripting

### 1.Which of the following commands will output a list of all files in the current directory?

    echo *

### 2.Which module can you load in a Python script to take advantage of star [*] like in BASH?

    Glob

### 3.Conditional execution is based on the _____ of commands.

    exit status

### 4.What command evaluates the conditions received on exit to verify that there is an exit status of 0 when the conditions are true, and 1 when they are false?

    test

### 5.The opening square bracket ([), when combined with the closing square bracket (]), is an alias for which command?

    test

