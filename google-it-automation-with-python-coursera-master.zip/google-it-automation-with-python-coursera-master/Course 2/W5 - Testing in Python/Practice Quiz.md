# Practice Quiz: Simple Tests

### 1.You can verify that software code behaves correctly using test ___.

  Cases

### 2.What is the most basic way of testing a script?

  Different parameters with expected results.

### 3.When a test is codified into its own software, what kind of test is it?

  Automatic test

### 4.Using _____ simplifies the testing process, allowing us to verify the program's behavior repeatedly with many possible values.

  test cases

### 5.The more complex our code becomes, the more value the use of _____ provides in managing errors.

  software testing
