# Practice Quiz: Understanding Slowness

### 1.Which of the following will an application spend the longest time retrieving data from?

    The network

### 2.Which tool can you use to verify reports of 'slowness' for web pages served by a web server you manage?

    The ab tool

### 3.If our computer running Microsoft Windows is running slow, what performance monitoring tools can we use to analyze our system resource usage to identify the bottleneck? (Check all that apply)

    Performance Monitor
    Resource Monitor

### 4.Which of the following programs is likely to run faster and more efficiently, with the least slowdown?

    A program small enough to fit in RAM

### 5.What might cause a single application to slow down an entire system? (Check all that apply)

    A memory leak
    Handling files that have grown too large
