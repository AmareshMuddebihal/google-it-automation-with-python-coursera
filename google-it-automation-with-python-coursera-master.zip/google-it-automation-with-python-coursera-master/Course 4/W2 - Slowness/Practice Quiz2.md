# Practice Quiz: Slow Code

### 1.Which of the following is NOT considered an expensive operation?

    Using a dictionary

### 2.Which of the following may be the most expensive to carry out in most automation tasks in a script?

    Loops

### 3.Which of the following statements represents the most sound advice when writing scripts?

    Start by writing clear code, then speed it up only if necessary

### 4.In Python, what is a data structure that stores multiple pieces of data, in order, which can be changed later?

    Lists

### 5.What command, keyword, module, or tool can be used to measure the amount of time it takes for an operation or program to execute? (Check all that apply)

    time
    kcachegrind
    cProfile


