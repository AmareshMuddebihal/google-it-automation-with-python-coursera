# Practice Quiz: Managing Our Time

### 1.Using the Eisenhower Decision Matrix, which of the following is an example of an event or task that is both Important, and Urgent?

    Internet connection is down

### 2.You’re working on a web server issue that’s preventing all users from accessing the site. You then receive a call from user to reset their user account password. Which appropriate action should you take when prioritizing your tasks?

    Ask the user to open a support ticket.

### 3.What is it called when we make more work for ourselves later by taking shortcuts now?

    Technical debt

### 4.What is the first step of prioritizing our time properly?

    Make a list of all tasks

### 5.If an issue isn't solved within the time estimate that you provided, what should you do? (Select all that apply)

    Explain why
    Give an updated time estimate
