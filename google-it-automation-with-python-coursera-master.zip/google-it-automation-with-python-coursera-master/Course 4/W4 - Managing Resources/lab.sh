
ls
sudo chmod 777 ~/start_date_report.py
./start_date_report.py

nano ~/start_date_report.py
# Eg. year = int(input('Enter a value for the year: '))

./start_date_report.py

time ./start_date_report.py


nano ~/start_date_report.py