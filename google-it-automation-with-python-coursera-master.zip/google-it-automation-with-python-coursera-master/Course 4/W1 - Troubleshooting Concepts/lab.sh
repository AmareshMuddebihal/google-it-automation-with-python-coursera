cd ~/scripts
ls
cat greetings.py
sudo chmod 777 greetings.py
./greetings.py


nano greetings.py

# print("hello " + name + ", your random number is " + str(number))

./greetings.py
