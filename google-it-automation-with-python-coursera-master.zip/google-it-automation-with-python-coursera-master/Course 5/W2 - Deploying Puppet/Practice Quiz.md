# Practice Quiz: Deploying Puppet Locally

### 1.Puppet evaluates all functions, conditionals, and variables for each individual system, and generates a list of rules for that specific system. What are these individual lists of rules called?

    Catalogs

### 2.After we install new modules that were made and shared by others, which folder in the module's directory will contain the new functions and facts?

    lib

### 3.What file extension do manifest files use?

    .pp

### 4.What is contained in the metadata.json file of a Puppet module?

    Additional data about the module

### 5.What does Puppet syntax dictate we do when referring to another resource attribute?

    Capitalize the attribute
