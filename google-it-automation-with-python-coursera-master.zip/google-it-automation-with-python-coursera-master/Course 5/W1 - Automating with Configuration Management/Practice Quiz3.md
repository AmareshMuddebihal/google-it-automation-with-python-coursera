# Practice Quiz: The Building Blocks of Configuration Management

### 1.How is a declarative language different from a procedural language?

    A declarative language defines the goal; a procedural language defines the steps to achieve a goal.

### 2.Puppet facts are stored in hashes. If we wanted to use a conditional statement to perform a specific action based on a fact value, what symbol must precede the facts variable for the Puppet DSL to recognize it?

    $

### 3.What does it mean that Puppet is stateless?

    There is no state being kept between runs of the agent.

### 4.What does the "test and repair" paradigm mean in practice?

    We should only take actions when testing determines they need to be done to reach the requested state

### 5.Where, in Puppet syntax, are the attributes of a resource found?

    Inside the curly braces after the resource type
