# Practice Quiz: Monitoring & Alerting

### 1.What is a Service Level Agreement?

    A strict commitment between a provider and a client.

### 2.What is the most important aspect of an alert?

    It must be actionable.

### 3.Which part of an HTTP message from a web server is useful for tracking the overall status of the response and can be  monitored and logged?

    The response code in the server's message

### 4.To set up a new alert, we have to configure the _____ that triggers the alert.

    Condition

### 5.When we collect metrics from inside a system, this is known as ______ monitoring.

    White-box
