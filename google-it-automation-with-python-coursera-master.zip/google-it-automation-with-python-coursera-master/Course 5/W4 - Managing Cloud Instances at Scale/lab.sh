


sudo systemctl status apache2

sudo systemctl restart apache2

sudo systemctl status apache2

sudo netstat -nlp

ps -ax | grep python3

cat /usr/local/bin/jimmytest.py

sudo kill [process-id]

ps -ax | grep python3

sudo systemctl --type=service | grep jimmy

sudo systemctl stop jimmytest && sudo systemctl disable jimmytest

sudo netstat -nlp

sudo systemctl start apache2