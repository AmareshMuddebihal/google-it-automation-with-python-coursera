# Practice Quiz: Building Software for the Cloud

### 1.What is latency in terms of Cloud storage?

    The amount of time it takes to complete a read or write operation.

### 2.Which of the following statements about sticky sessions are true? (Select all that apply.)

    All requests from the same client always go to the same backend server.
    They should only be used when needed.
    They can cause problems during migration.

### 3.If you run into limitations such as rate limits or utilization limits, you should contact the Cloud provider and ask for a _____.

    Quota increase

### 4.What is the term referring to everything needed to run a service?

    Environment

### 5.What is the term referring to a network of hosts spread in different geographical locations, allowing ISPs to be as close as possible to content?

    Content delivery network
