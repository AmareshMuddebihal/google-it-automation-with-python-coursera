# Practice Quiz: Using Git

### 1.Before changes in new files can be added to the Git directory, what command will tell Git to track our file in the list of changes to be committed?

    git add

### 2.Which command would we use to review the commit history for our project?

    git log

### 3.What command would we use to make Git track our file?

    git add

### 4.Which command would we use to look at our config?

    git config -l

### 5.Which command would we use to view pending changes?

    git status
