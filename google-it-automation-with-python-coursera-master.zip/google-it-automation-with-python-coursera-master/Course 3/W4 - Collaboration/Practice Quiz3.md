# Practice Quiz: Managing Collaboration

### 1.How do we reference issues in our commits with automatic links?

    By using one of the keywords followed by a hashtag and the issue number.

### 2.What is an artifact in terms of continuous integration/continuous delivery (CI/CD) pipelines?

    Any file generated as part of the CI/CD pipeline.

### 3.Which of the following statements are good advice for project maintainers? (Check all that apply)

    Reply promptly to pull-requests
    Understand any changes you accept
    Use an issue tracker

### 4.Which statement best represents what a Continuous Integration system will do?

    Run tests automatically

### 5.Which statement best represents what a Continuous Delivery (CD) system will do?

    Update with incremental rollouts
