
cd ~/food-scripts
ls

cat favorite_foods.log

./food_count.py

./food_question.py

git status

git log

git config user.name "Ahmed W. Yousif"
git config user.email "eng.ahmed.w.yousif@hotmail.com"

git branch improve-output
git checkout improve-output

nano food_count.py
./food_count.py

git add food_count.py

git commit -m "Adding a line in the output describing the utility of food_count.py script"

###################################################################################3

./food_question.py

git log 

git revert 21cf376832fa6eace35c0bf9e4bae4a3400452e9

./food_question.py

git checkout master

git merge improve-output

git status

git log