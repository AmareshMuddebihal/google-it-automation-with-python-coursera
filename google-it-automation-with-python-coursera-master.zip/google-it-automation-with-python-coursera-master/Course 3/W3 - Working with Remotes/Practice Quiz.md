# Practice Quiz: Introduction to GitHub


### 1.When we want to update our local repository to reflect changes made in the remote repository, which command would we use?

    git pull

### 2.git config --global credential.helper cache allows us to configure the credential helper, which is used for ...what?

    Allowing automated login to GitHub

### 3. Name two ways to avoid having to enter our password when retrieving and when pushing changes to the repo. (Check all that apply)

Use a credential helper
Create an SSH key-pair

### 4. Name the command that gathers all the snapshots we've taken and sends them to the remote repository.

    git push
